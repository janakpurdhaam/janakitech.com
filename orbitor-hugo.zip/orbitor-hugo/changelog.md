## Version 1.0.0 (8 sep 2019)
- Initial template
- Hugo version 0.56.1
- Bootstrap version 4.1.1

## Version 1.0.1 (8 sep 2019)
- Modified blog sidebar

## Version 2.0.0 (4 nov 2020)
- Rebuild with forestry CMS
- Hugo version 0.76.5
- Optimised page speed
- Remove extra files and plugins