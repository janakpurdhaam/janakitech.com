---
title: "Project california"
date: 2019-09-05T15:24:04+06:00
draft: false
description: "This is meta description"
page_header_bg: "images/bg/section-bg5.jpg"
category: "Web Development"
image : "images/portfolio/2.jpg"
---


### Engaging content and flexible User experience help to grow more

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, 

remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

- **Project Name:** Business Accounting
- **Client:** Company Name Inc.
- **Project Start Date:** February 18, 2018
- **Project Completion Date:** January 25, 2018
- **Project url:** www.example.com