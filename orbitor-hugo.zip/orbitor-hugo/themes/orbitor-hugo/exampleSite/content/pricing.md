---
title: "Our Pricing"
page_header_bg: "images/bg/section-bg5.jpg"
description: "This is meta description"
layout: "pricing"
draft: false

################ pricing ##################
pricing:
  enable : true
  title : "Our pricing"
  content : "Labore tempore ratione magnam iste sint dicta dolor doloremque similique tempora optio, expedita veritatis enim nam itaque illum excepturi id dolores, officia?"
  pricing_table:
  # pricing table loop
  - name : "Basic"
    price : "$29.99"
    price_per : "Yearly"
    services:
    - "50 gb Hosting"
    - "Business Analysis"
    - "24 Hours Support"
    - "Customer Management"
    button:
      label: "Choose plan"
      link : "#"
      
  # pricing table loop
  - name : "Standard"
    price : "$49.99"
    price_per : "Yearly"
    services:
    - "50 gb Hosting"
    - "Business Analysis"
    - "24 Hours Support"
    - "Customer Management"
    button:
      label: "Choose plan"
      link : "#"
      
  # pricing table loop
  - name : "Premium"
    price : "$99.99"
    price_per : "Yearly"
    services:
    - "50 gb Hosting"
    - "Business Analysis"
    - "24 Hours Support"
    - "Customer Management"
    button:
      label: "Choose plan"
      link : "#"
---