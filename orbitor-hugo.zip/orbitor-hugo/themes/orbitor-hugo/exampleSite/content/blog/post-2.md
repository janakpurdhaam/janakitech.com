---
title: "In the news: this week’s top news stories"
date: 2019-09-05T15:24:04+06:00
draft: false
description: "This is meta description"
page_header_bg: "images/bg/section-bg5.jpg"
image: "images/blog/blog-2.jpg"
categories: ["Trends"]
tags: ["Creative", "HTML"]
---
Non illo quas blanditiis repellendus laboriosam minima animi. Consectetur accusantium pariatur repudiandae!

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus natus, consectetur? Illum libero
vel nihil nisi quae, voluptatem, sapiente necessitatibus distinctio voluptates, iusto qui. Laboriosam
autem, nam voluptate in beatae.

> A brand for a company is like a reputation for a person. You earn reputation by trying to do hard things well.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, rerum beatae repellat tenetur
incidunt quisquam libero dolores laudantium. Nesciunt quis itaque quidem, voluptatem autem eos animi
laborum iusto expedita sapiente.

**sensation of stress from our first instances of social rejection ridicule. We quickly learn to fear and thus automatically.**